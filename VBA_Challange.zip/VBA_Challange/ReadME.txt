Hi,
What i did:
1.defined types of data
2. defined formulas
3. For future result made base line
4. Made For loop not only for Tickers but for all nesseccary info
5. When picking Max and min results - connected thru formula with naboring Ticker column to pull corresponding Ticker value as well
